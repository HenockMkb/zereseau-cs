<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $to = "contact@ze-reseau.com";
        $subject = "Nouvel abonnement ZeReseau";
        $message = "Nouvelle inscription à la newsletter : " . $email;
        $headers = "From: noreply@ze-reseau.com" . "\r\n" .
                   "Reply-To: " . $email . "\r\n" .
                   "X-Mailer: PHP/" . phpversion();

        mail($to, $subject, $message, $headers);
        echo "Merci pour votre inscription !";
    } else {
        echo "Adresse e-mail invalide.";
    }
} else {
    echo "Méthode non autorisée.";
}
?>
